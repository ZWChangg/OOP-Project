import javafx.application.Application;
import javafx.stage.Stage;

/**
 * Main application class for the Movie Ticket Booking application.
 * This class extends the JavaFX Application class and serves as the entry point for the application.
 */
public class MovieTicketApplication extends Application {

    /**
     * The start method is the main entry point for all JavaFX applications.
     * It is called after the application is launched and is responsible for setting up the initial scene and stage.
     *
     * @param primaryStage The primary stage for this application onto which the application scene can be set.
     */
    @Override
    public void start(Stage primaryStage) {
        // Create an instance of MovieSelectionScreen
        MovieSelectionScreen movieSelection = new MovieSelectionScreen();
        
        // Call the show method to display the movie selection screen on the primary stage
        movieSelection.show(primaryStage);
    }

    /**
     * The main method is the entry point for launching the application.
     * This method calls the launch method, which internally sets up the JavaFX environment and calls the start method.
     *
     * @param args Command line arguments, if any.
     */
    public static void main(String[] args) {
        // Launch the JavaFX application, which calls the start method
        launch(args);
    }
}
