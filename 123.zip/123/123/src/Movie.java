import java.util.List;

public class Movie {
    // The title of the movie
    private String title;
    
    // A list of seats available for the movie
    private List<Seat> seats;

    // Constructor to initialize the movie title and list of seats
    public Movie(String title, List<Seat> seats) {
        this.title = title;   // Set the title of the movie
        this.seats = seats;   // Set the list of seats for the movie
    }

    // Getter method to retrieve the title of the movie
    public String getTitle() {
        return title;
    }

    // Getter method to retrieve the list of seats for the movie
    public List<Seat> getSeats() {
        return seats;
    }
}
