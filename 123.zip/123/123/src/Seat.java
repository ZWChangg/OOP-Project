/**
 * The Seat class represents a single seat in a movie theater.
 * It contains a seat identifier and tracks whether the seat is booked.
 */
public class Seat {
    // The unique identifier for the seat (e.g., "A1", "B5").
    private String seatId;

    // Boolean flag to track if the seat is booked or not.
    private boolean isBooked;

    /**
     * Constructor to create a new Seat object with a given seat ID.
     * By default, the seat is not booked.
     *
     * @param seatId The unique identifier for the seat.
     */
    public Seat(String seatId) {
        this.seatId = seatId;
        this.isBooked = false;  // Initialize the seat as unbooked.
    }

    /**
     * Returns the unique seat identifier.
     *
     * @return The seat ID as a string.
     */
    public String getSeatId() {
        return seatId;
    }

    /**
     * Checks if the seat is booked.
     *
     * @return True if the seat is booked, false otherwise.
     */
    public boolean isBooked() {
        return isBooked;
    }

    /**
     * Toggles the booking status of the seat.
     * If the seat is currently booked, this method will unbook it, and vice versa.
     */
    public void toggleBooking() {
        isBooked = !isBooked;  // Switch the booking status (book/unbook).
    }
}
