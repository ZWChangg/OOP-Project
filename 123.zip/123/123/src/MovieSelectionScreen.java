import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class MovieSelectionScreen {

    // Method to show the movie selection screen
    public void show(Stage primaryStage) {
         // Load images for movies
        ImageView image1 = new ImageView(new Image(getClass().getResource("resources/images/SuperMan.jpeg").toExternalForm()));
        ImageView image2 = new ImageView(new Image(getClass().getResource("resources/images/Avatar.jpg").toExternalForm()));
        ImageView image3 = new ImageView(new Image(getClass().getResource("resources/images/Danger.jpg").toExternalForm()));

        image1.setFitWidth(200);
        image1.setFitHeight(300);
        image2.setFitWidth(200);
        image2.setFitHeight(300);
        image3.setFitWidth(200);
        image3.setFitHeight(300);

        // Create movie buttons with corresponding movie titles
        Button btMv1 = createMovieButton("Super Man", image1);
        Button btMv2 = createMovieButton("Avatar", image2);
        Button btMv3 = createMovieButton("Storm", image3);

        // Create a GridPane layout to arrange images and buttons
        GridPane pane = new GridPane();
        pane.addRow(0, image1, image2, image3); // First row for images
        pane.addRow(1, btMv1, btMv2, btMv3);    // Second row for buttons
        pane.setHgap(40);                       // Horizontal gap between elements
        pane.setVgap(10);                       // Vertical gap between rows
        pane.setPadding(new Insets(20, 20, 20, 20)); // Padding around the grid

        // Set the scene and display the primary stage
        Scene scene = new Scene(pane);
        primaryStage.setTitle("Booking Movie Ticket");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Method to create a movie button that navigates to the movie booking screen   
    private Button createMovieButton(String movieName, ImageView image) {
        Button button = new Button(movieName);
        button.setPrefWidth(200); // Set button width to match the image
        button.setOnAction(e -> showMovieScreen(movieName)); // Show movie booking screen on click
        return button;
    }

    // Method to show the movie booking screen for the selected movie
    private void showMovieScreen(String movieName) {
        MovieScreen movieScreen = new MovieScreen(movieName);
        movieScreen.show();// Navigate to the movie screen for ticket booking
    }
}
