import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class MovieScreen {

    private String movieName = "";
    private double totalAmount = 0;
    private Label lblAmount = new Label();
    private List<String> bookedSeats = new ArrayList<>();
    private ComboBox<String> timeComboBox;
    private Stage stage;
    private GridPane seatGrid;
    private List<Button> seatButtons = new ArrayList<>();
    private Button btUse;

    // Database credentials
    static final String DB_URL = "jdbc:mysql://localhost:3306/movie_booking";
    static final String USER = "root";
    static final String PASS = "";
    
    // SQL queries
    static final String INSERT_QUERY = "INSERT INTO bookings (id, movieName, showTime, seat, totalAmount) VALUES (?, ?, ?, ?)";
    static final String SELECT_BOOKED_SEATS_QUERY = "SELECT seat FROM bookings WHERE movieName = ? AND showTime = ?";

    // Convert time from 12-hour format to 24-hour format
    private String convertTimeFormat(String time) {
        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH);
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

        time = time.trim();
        try {
            LocalTime localTime = LocalTime.parse(time, inputFormatter);
            return localTime.format(outputFormatter);
        } catch (DateTimeParseException e) {
            return null;
        }
    }

    // Constructor to initialize MovieScreen with the movie name
    public MovieScreen(String movieName) {
        this.movieName = movieName;
    }

    // Show the movie screen where users select seats and times
    public void show() {
        stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle(movieName);

        // Dropdown for selecting movie times
        timeComboBox = new ComboBox<>();
        timeComboBox.getItems().addAll("10:00 AM", "2:00 PM", "4:00 PM", "6:00 PM");
        timeComboBox.setPromptText("Select a time");
        timeComboBox.setOnAction(e -> updateSeatAvailability());

        // Labels and input fields for movie selection and member code
        Label lblMovie = new Label("Please select your time and seat.");
        Label lblMemberCode = new Label("Member Code: ");
        TextField memberCodeField = new TextField();

        // Grid layout for displaying seats
        seatGrid = createSeatGrid();

        // Button to submit the booking
        Button btSubmit = new Button("Book Ticket");
        btSubmit.setOnAction(e -> bookTicket());

        // Button to apply member code discount
        btUse = new Button("Use");
        btUse.setOnAction(e -> applyMemberCode(memberCodeField.getText()));
        btUse.setDisable(false);  // Enable "Use" button when showing screen

        // Layout structure for the movie screen
        HBox memberCodeBox = new HBox(10, lblMemberCode, memberCodeField, btUse);
        VBox movieLayout = new VBox(20, lblMovie, timeComboBox, seatGrid, memberCodeBox, lblAmount, btSubmit);
        movieLayout.setPadding(new Insets(20, 20, 40, 20));

        // Set the scene for the window
        Scene scene = new Scene(movieLayout);
        stage.setScene(scene);
        stage.showAndWait();
    }

    // Create a grid layout for seats with buttons representing each seat
    private GridPane createSeatGrid() {
        final int NUM_ROWS = 5;  // Number of seat rows
        final int SEATS_PER_ROW = 8;  // Number of seats per row
        GridPane seatGrid = new GridPane();
        seatGrid.setHgap(10);
        seatGrid.setVgap(10);

        // Generate seat buttons for each row and seat
        for (int row = 0; row < NUM_ROWS; row++) {
            for (int seat = 0; seat < SEATS_PER_ROW; seat++) {
                Button seatButton = new Button("" + (char) ('A' + row) + (seat + 1));
                seatButton.setMinSize(40, 40);
                seatButton.setOnAction(e -> toggleSeatStatus(seatButton));
                seatGrid.add(seatButton, seat, row);
                seatButtons.add(seatButton);  // Add seat buttons to list for later access
            }
        }
        return seatGrid;
    }

    // Update seat availability based on selected movie time
    private void updateSeatAvailability() {
        if (timeComboBox.getValue() == null) return;  // Ensure a time is selected

        String formattedTime = convertTimeFormat(timeComboBox.getValue());
        if (formattedTime == null) {
            showAlert("Invalid time format.");
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(SELECT_BOOKED_SEATS_QUERY)) {

            pstmt.setString(1, movieName);
            pstmt.setString(2, formattedTime);

            ResultSet rs = pstmt.executeQuery();

            // Reset seat buttons to available
            for (Button seatButton : seatButtons) {
                seatButton.setDisable(false);
                seatButton.setTextFill(Color.BLACK);
            }

            // Disable buttons for already booked seats
            while (rs.next()) {
                String bookedSeat = rs.getString("seat");
                for (Button seatButton : seatButtons) {
                    if (seatButton.getText().equals(bookedSeat)) {
                        seatButton.setDisable(true);
                        seatButton.setTextFill(Color.GRAY);  // Gray indicates booked seats
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Handle the process of booking a ticket
    private void bookTicket() {
        if (timeComboBox.getValue() != null && totalAmount != 0) {
            String formattedTime = convertTimeFormat(timeComboBox.getValue());
            if (formattedTime != null) {
                saveBookingToDatabase(formattedTime);  // Save booking to database
                showBooking();  // Display success message
            } else {
                showAlert("Invalid time format.");
            }
        } else {
            showAlert("Please select your time and seat.");
        }
    }

    // Save the booking details to the database
    private void saveBookingToDatabase(String formattedTime) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(INSERT_QUERY)) {

            // Insert booking details for each seat
            for (String seat : bookedSeats) {
                pstmt.setString(1, movieName);
                pstmt.setString(2, formattedTime);
                pstmt.setString(3, seat);
                pstmt.setDouble(4, totalAmount);

                pstmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Toggle seat status (selected or unselected)
    private void toggleSeatStatus(Button seatButton) {
        if (timeComboBox.getValue() == null) {
            showAlert("Please select a time before choosing seats.");
            return;
        }

        // If the seat is already selected, unselect it
        if (seatButton.getTextFill() == Color.RED) {
            seatButton.setTextFill(Color.BLACK);
            bookedSeats.remove(seatButton.getText());
            totalAmount -= 15.0;
        } 
        // Otherwise, select the seat if it's not disabled
        else if (!seatButton.isDisabled()) {
            seatButton.setTextFill(Color.RED);
            bookedSeats.add(seatButton.getText());
            totalAmount += 15.0;
        }
        lblAmount.setText("Total Amount: RM" + totalAmount);  // Update total amount
    }

    // Apply member code discount
    private void applyMemberCode(String code) {
        if ("1234".equals(code)) {
            totalAmount -= 3.0;
            lblAmount.setText("Total Amount: RM" + totalAmount);
            btUse.setDisable(true);  // Disable button after applying code
        } else {
            showAlert("Invalid member code");
        }
    }

    // Display a booking confirmation message
    private void showBooking() {
        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL);
        popupStage.setTitle("Successful booking!");

        String selectedTime = timeComboBox.getValue();
        Label lblShow = new Label("Successfully booked tickets! Please bring your receipt and pay at the counter.");
        Label lblSelected = new Label("Your seats: " + bookedSeats + "\nYour time : " + selectedTime + "\nYour total amount: RM" + totalAmount);
        lblShow.setFont(new Font(20));
        VBox showLayout = new VBox(20, lblShow, lblSelected);
        showLayout.setPadding(new Insets(20));

        Scene showScene = new Scene(showLayout);
        popupStage.setScene(showScene);

        // Close the booking stage after showing confirmation
        popupStage.setOnHiding(e -> stage.close());

        popupStage.showAndWait();
    }

    // Display an alert with a custom message
    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
