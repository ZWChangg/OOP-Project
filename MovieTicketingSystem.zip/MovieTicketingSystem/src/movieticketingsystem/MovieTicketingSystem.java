/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package movieticketingsystem;

/**
 *
 * @author chang 
 */
import javafx.application.Application;
import javafx.stage.Stage;
import java.util.List;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.sql.ResultSet;
import static javafx.application.Application.launch;


import javafx.stage.Stage;

/**
 * This is the blueprint of MovieTicketingSystem
 * @author chang
 */

public class MovieTicketingSystem extends Application  {

    /**
     *
     * @param primaryStage
     */
       @Override
    public void start(Stage primaryStage) {
        MovieSelectionScreen movieSelection = new MovieSelectionScreen();
        movieSelection.show(primaryStage);
    }
    
    
    /**
     * class Movie
     */
   public class Movie {
    private String title;
    private List<Seat> seats;

           /**
            *
            * @param title
            * String title
            * @param seats
            * List Seat seats
            */
           public Movie(String title, List<Seat> seats) {
        this.title = title;
        this.seats = seats;
    }

           /**
            *
            * @return title
            */
           public String getTitle() {
        return title;
    }

           /**
            *
            * @return seats
            */
           public List<Seat> getSeats() {
        return seats;
    }
       }

    /**
     * class MovieSelectionScreen
     */
   public class MovieSelectionScreen {

           /**
            *
            * @param primaryStage
            */
           public void show(Stage primaryStage) {
        ImageView image1 = new ImageView(new Image(getClass().getResource("resources/images/SuperMan.jpeg").toExternalForm()));
        ImageView image2 = new ImageView(new Image(getClass().getResource("resources/images/Avatar.jpg").toExternalForm()));
        ImageView image3 = new ImageView(new Image(getClass().getResource("resources/images/Danger.jpg").toExternalForm()));

        image1.setFitWidth(200);
        image1.setFitHeight(300);
        image2.setFitWidth(200);
        image2.setFitHeight(300);
        image3.setFitWidth(200);
        image3.setFitHeight(300);

        Button btMv1 = createMovieButton("Super Man", image1);
        Button btMv2 = createMovieButton("Avatar", image2);
        Button btMv3 = createMovieButton("Storm", image3);

        GridPane pane = new GridPane();
        pane.addRow(0, image1, image2, image3);
        pane.addRow(1, btMv1, btMv2, btMv3);
        pane.setHgap(40);
        pane.setVgap(10);
        pane.setPadding(new Insets(20, 20, 20, 20));

        Scene scene = new Scene(pane);
        primaryStage.setTitle("Booking Movie Ticket");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private Button createMovieButton(String movieName, ImageView image) {
        Button button = new Button(movieName);
        button.setPrefWidth(200);
        button.setOnAction(e -> showMovieScreen(movieName));
        return button;
    }

    private void showMovieScreen(String movieName) {
        MovieScreen movieScreen = new MovieScreen(movieName);
        movieScreen.show();
    }
       }


    /**
     * class Seat
     */
   public class Seat {
    private String seatId;
    private boolean isBooked;

           /**
            *
            * @param seatId
            * String seatId
            */
           public Seat(String seatId) {
        this.seatId = seatId;
        this.isBooked = false;
    }

           /**
            *
            * @return seatId
            */
           public String getSeatId() {
        return seatId;
    }

           /**
            *
            * @return isBooked
            */
           public boolean isBooked() {
        return isBooked;
    }

           /**
            *
            */
           public void toggleBooking() {
        isBooked = !isBooked;
    }
       }


    /**
     * class MovieScreen
     */
   public class MovieScreen {

    private String movieName = "";
    private double totalAmount = 0;
    private Label lblAmount = new Label();
    private List<String> bookedSeats = new ArrayList<>();
    private ComboBox<String> timeComboBox;
    private Stage stage;
    private GridPane seatGrid;
    private List<Button> seatButtons = new ArrayList<>();
    private Button btUse;

    static final String DB_URL = "jdbc:mysql://localhost:3306/movieticket";
    static final String USER = "root";
    static final String PASS = "12345";
    static final String INSERT_QUERY = "INSERT INTO bookings (movieName, showTime, seat, totalAmount) VALUES (?, ?, ?, ?)";
    static final String SELECT_BOOKED_SEATS_QUERY = "SELECT seat FROM bookings WHERE movieName = ? AND showTime = ?";

    private String convertTimeFormat(String time) {
        DateTimeFormatter inputFormatter = DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH);
        DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern("HH:mm:ss");

        time = time.trim();
        try {
            LocalTime localTime = LocalTime.parse(time, inputFormatter);
            return localTime.format(outputFormatter);
        } catch (DateTimeParseException e) {
            return null;
        }
    }

           /**
            *
            * @param movieName
            * String movieName
            */
           public MovieScreen(String movieName) {
        this.movieName = movieName;
    }
    
           /**
            *
            */
           public void show() {
        stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle(movieName);
    
        timeComboBox = new ComboBox<>();
        timeComboBox.getItems().addAll("10:00 AM", "2:00 PM", "4:00 PM", "6:00 PM");
        timeComboBox.setPromptText("Select a time");
        timeComboBox.setOnAction(e -> updateSeatAvailability());
    
        Label lblMovie = new Label("Please select your time and seat.");
        Label lblMemberCode = new Label("Member Code: ");
        TextField memberCodeField = new TextField();
    
        seatGrid = createSeatGrid();
    
        Button btSubmit = new Button("Book Ticket");
        btSubmit.setOnAction(e -> bookTicket());
    
        btUse = new Button("Use");  // Initialize btUse here
        btUse.setOnAction(e -> applyMemberCode(memberCodeField.getText()));
        // Ensure the "Use" button is enabled every time the screen is shown
        btUse.setDisable(false);
    
        HBox memberCodeBox = new HBox(10, lblMemberCode, memberCodeField, btUse);
        VBox movieLayout = new VBox(20, lblMovie, timeComboBox, seatGrid, memberCodeBox, lblAmount, btSubmit);
        movieLayout.setPadding(new Insets(20, 20, 40, 20));
    
        Scene scene = new Scene(movieLayout);
        stage.setScene(scene);
        stage.showAndWait();
    }
    
    

    private GridPane createSeatGrid() {
        final int NUM_ROWS = 5;
        final int SEATS_PER_ROW = 8;
        GridPane seatGrid = new GridPane();
        seatGrid.setHgap(10);
        seatGrid.setVgap(10);

        for (int row = 0; row < NUM_ROWS; row++) {
            for (int seat = 0; seat < SEATS_PER_ROW; seat++) {
                Button seatButton = new Button("" + (char) ('A' + row) + (seat + 1));
                seatButton.setMinSize(40, 40);
                seatButton.setOnAction(e -> toggleSeatStatus(seatButton));
                seatGrid.add(seatButton, seat, row);
                seatButtons.add(seatButton);  // Add button to list for later access
            }
        }
        return seatGrid;
    }

    private void updateSeatAvailability() {
        if (timeComboBox.getValue() == null) return;

        String formattedTime = convertTimeFormat(timeComboBox.getValue());
        if (formattedTime == null) {
            showAlert("Invalid time format.");
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(SELECT_BOOKED_SEATS_QUERY)) {

            pstmt.setString(1, movieName);
            pstmt.setString(2, formattedTime);

            ResultSet rs = pstmt.executeQuery();

            // Clear all seat buttons
            for (Button seatButton : seatButtons) {
                seatButton.setDisable(false);
                seatButton.setTextFill(Color.BLACK);
            }

            // Disable already booked seats
            while (rs.next()) {
                String bookedSeat = rs.getString("seat");
                for (Button seatButton : seatButtons) {
                    if (seatButton.getText().equals(bookedSeat)) {
                        seatButton.setDisable(true);
                        seatButton.setTextFill(Color.GRAY);  // Set to gray to indicate it's booked
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void bookTicket() {
        if (timeComboBox.getValue() != null && totalAmount != 0) {
            String formattedTime = convertTimeFormat(timeComboBox.getValue());
            if (formattedTime != null) {
                saveBookingToDatabase(formattedTime);
                showBooking();
            } else {
                showAlert("Invalid time format.");
            }
        } else {
            showAlert("Please select your time and seat.");
        }
    }

    private void saveBookingToDatabase(String formattedTime) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement pstmt = conn.prepareStatement(INSERT_QUERY)) {

            for (String seat : bookedSeats) {
                pstmt.setString(1, movieName);
                pstmt.setString(2, formattedTime);
                pstmt.setString(3, seat);
                pstmt.setDouble(4, totalAmount);

                pstmt.executeUpdate();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void toggleSeatStatus(Button seatButton) {
        // Check if a time has been selected
        if (timeComboBox.getValue() == null) {
            showAlert("Please select a time before choosing seats.");
            return;
        }
    
        if (seatButton.getTextFill() == Color.RED) {
            seatButton.setTextFill(Color.BLACK);
            bookedSeats.remove(seatButton.getText());
            totalAmount -= 15.0;
        } else if (!seatButton.isDisabled()) {
            seatButton.setTextFill(Color.RED);
            bookedSeats.add(seatButton.getText());
            totalAmount += 15.0;
        }
        lblAmount.setText("Total Amount: RM" + totalAmount);
    }

    private void applyMemberCode(String code) {
        if ("1234".equals(code)) {
            totalAmount -= 3.0;
            lblAmount.setText("Total Amount: RM" + totalAmount);
            // Disable the button after use
            btUse.setDisable(true);
        } else {
            showAlert("Invalid member code");
        }
    }
    

    private void showBooking() {
        Stage popupStage = new Stage();
        popupStage.initModality(Modality.APPLICATION_MODAL);
        popupStage.setTitle("Successful booking!");

        String selectedTime = timeComboBox.getValue();
        Label lblShow = new Label("Successful booked tickets! Please bring your receipt and pay at counter.");
        Label lblSelected = new Label("Your seats: " + bookedSeats + "\nYour time : " + selectedTime + "\nYour total amount: RM" + totalAmount);
        lblShow.setFont(new Font(20));
        VBox showLayout = new VBox(20, lblShow, lblSelected);
        showLayout.setPadding(new Insets(20));

        Scene showScene = new Scene(showLayout);
        popupStage.setScene(showScene);

        popupStage.setOnHiding(e -> stage.close());

        popupStage.showAndWait();
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
       }
    /**
     *
     * @param args
     */
    public static void main(String[] args) {
               launch(args);
    }
    
}


   